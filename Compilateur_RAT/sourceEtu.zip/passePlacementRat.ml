(* Module de la passe de gestion des types *)
module PassePlacementRat : Passe.Passe with type t1 = Ast.AstType.programme and type t2 = Ast.AstPlacement.programme =
struct

  open Tds
  open Type
  open Exceptions
  open Ast.AstType
  open Ast
  open AstPlacement

  type t1 = Ast.AstType.programme
  type t2 = Ast.AstPlacement.programme


  let rec analyse_placement_instruction  base reg instr = 
    match instr with                        
    
  
                                                                                
    |AstType.Conditionnelle(_,b1,b2) -> analyse_placement_bloc base reg b1;
                                        analyse_placement_bloc base reg b2;
                                        0
     
    |AstType.TantQue(_,b) -> analyse_placement_bloc base reg  b;
                            0
    
    | AstType.Declaration(info,_) -> begin match info_ast_to_info info with  
                                   |InfoVar (_,t,_,_) -> Tds.modifier_adresse_info base reg info;
                                                         Type.getTaille t 
                                   |_ -> assert false
                                    end
                                    
                                           
  | _ -> 0  
  (* analyse_type_bloc : AstSyntax.bloc -> AstTds.bloc *)
  (* Paramètre tds : la table des symboles courante *)
  (* Paramètre li : liste d'instructions à analyser *)
  (* Vérifie la bonne utilisation des identifiants et tranforme le bloc
  en un bloc de type AstTds.bloc *)
  (* Erreur si mauvaise utilisation des identifiants *)
  and analyse_placement_bloc base reg li =
   List.fold_left (fun base i -> base + analyse_placement_instruction base reg i)  base li |>
   ignore
  
  
  
   let analyse_parametres  infos = 
    (List.fold_right (fun info base -> match info_ast_to_info info with
                                        |InfoVar (_,t,_,_)-> let base' = base - Type.getTaille t in 
                                         let () = Tds.modifier_adresse_info base' "LB" info in
                                         base'
                                         | _ -> assert false) infos
                                         (0)) |> ignore
  (* analyse_tds_fonction : AstSyntax.fonction -> AstTds.fonction *)
  (* Paramètre tds : la table des symboles courante *)
  (* Paramètre : la fonction à analyser *)
  (* Vérifie la bonne utilisation des identifiants et tranforme la fonction
  en une fonction de type AstTds.fonction *)
  (* Erreur si mauvaise utilisation des identifiants *)
  let analyse_placement_fonction  (AstType.Fonction(info,infos,li)) =
    let () = analyse_parametres  infos in
    let _ = analyse_placement_bloc 3 "LB" li in
    AstPlacement.Fonction (info,infos,li)
   
  
  
  




let analyser (AstType.Programme(fonctions,prog)) =
  let lf = List.map (analyse_placement_fonction) fonctions in 
  let () = analyse_placement_bloc 0 "SB" prog in
  AstPlacement.Programme(lf,prog)

end