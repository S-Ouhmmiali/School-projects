(* Module de la passe de gestion des types *)

module PasseCodeRatToTam : Passe.Passe with type t1 = Ast.AstPlacement.programme and type t2 = string =
struct

  open Tds
  open Type
  open Exceptions
  
  open Ast
  open AstType

  type t1 = Ast.AstPlacement.programme
  type t2 = string
  


  let rec analyse_expression expr = 
    match expr with  
    |Ident(info_ast) -> begin match info_ast_to_info info_ast with 
                          |InfoVar(n,t,d,r) -> "LOAD "^"(" ^string_of_int(getTaille t)^")" ^ string_of_int d ^ "[" ^ r ^ "]"^"\n"
                          |InfoConst (_,n) -> "LOADL "^string_of_int(n)^"\n"
                          |_ -> failwith "" 
                        end
    |Binaire(b,e1,e2) -> let x1 = (analyse_expression e1) in 
                        let x2 = (analyse_expression e2) in
                begin match b with
                | PlusInt -> x1 ^ x2 ^ "SUBR " ^"IAdd\n" 
                | MultInt -> x1 ^ x2 ^ "SUBR " ^"IMul\n" 
                | MultRat -> x1 ^ x2 ^"CALL (SB)" ^"rmul\n" 
                | PlusRat -> x1 ^ x2 ^"CALL (SB)" ^"radd\n" 
                | Fraction -> x1 ^x2 ^ "CALL (SB) norm\n"
                | EquInt -> x1 ^x2 ^ "SUBR " ^"IEq\n" 
                | EquBool ->  x1 ^x2 ^ "CALL (SB) req\n" 
                |_ -> x1 ^ x2
        end
   |Unaire(b,e)  -> (analyse_expression e)^"\n"
   |Entier(n) -> "LOADL "^string_of_int(n)^"\n"
   |Booleen(b) -> "LOADL " ^ (if b=true then "1\n" else "0\n")
   |AppelFonction(info_ast, le) -> ""
   |_ -> ""                                             


let rec codeliste l =
 match l with
  |[] -> ""
  |t::q -> t^"\n"^(codeliste q) 
let rec analyse_instruction  instr = 
  match instr with                         
  | Declaration(info_ast,e) -> begin match info_ast_to_info info_ast with 
                                      |InfoVar(_,t,d,r) -> (analyse_expression e) ^"PUSH " ^string_of_int(getTaille t) ^"\n"
                                      ^analyse_expression e ^"\n"^ "STORE " ^ "("^ string_of_int (getTaille t)^ ") "^ string_of_int d ^ "[" ^ r ^ "]\n"
                                      | _ -> "" 
                              end
 
  | Affectation(info_ast,e) -> begin  match info_ast_to_info info_ast with
                              |InfoVar(_,t,d,r) ->(analyse_expression e)^"STORE " ^ "("^ string_of_int (getTaille t)^ ") "^ string_of_int d ^ "[" ^ r ^ "]"^"\n"
                              | _ -> "" 
                              end
  |TantQue (b,e) -> "whiledebut" ^"\n"^(analyse_expression b)^"JumpIf(0) whilefin" ^
                                        (analyse_bloc e) ^ "Jump whiledebut" ^"\n" ^"whilefin"
  |Conditionnelle(b,e1,e2) -> (analyse_expression b)^"JumpIf(0) else\n" ^
                                        (analyse_bloc e1) ^"else\n" ^
                                        (analyse_bloc e2)

  
  |AffichageInt(e) -> analyse_expression e ^ "SUBR " ^"IOut\n"
  |AffichageBool(e) -> analyse_expression e ^ "SUBR " ^"Bout\n"
  |AffichageRat(e) -> analyse_expression e ^ "CALL " ^"rout\n"
  |_ -> ""                            
    
 

and analyse_bloc li =
let l = List.map( analyse_instruction) li in
codeliste l
 





let analyse_fonction (AstPlacement.Fonction(n,lp,li)) = ""

         





       
let analyser (AstPlacement.Programme (fonctions,prog)) =
  let nfl = List.map (analyse_fonction) fonctions in
  let nf = codeliste nfl in
  let nb = (analyse_bloc prog)
  in nf ^ nb ^ "\nHALT"

end
