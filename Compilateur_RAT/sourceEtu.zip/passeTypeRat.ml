(* Module de la passe de gestion des types *)
module PasseTypeRat : Passe.Passe with type t1 = Ast.AstTds.programme and type t2 = Ast.AstType.programme =
struct

  open Tds
  open Type
  open Exceptions
  open Ast
  open AstType

  type t1 = Ast.AstTds.programme
  type t2 = Ast.AstType.programme


(* analyse_type_expression : AstSyntax.expression -> AstTds.expression *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre e : l'expression à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'expression
en une expression de type AstTds.expression *)
(* Erreur si mauvaise utilisation des identifiants *)
let rec analyse_type_expression e = 
     match e with  
      |AstTds.Entier(n) -> (Entier(n),Int)
      |AstTds.Booleen(b) -> (Booleen(b),Bool)
      |AstTds.Binaire(op,e1,e2) ->
                                      let (x1,t1) = analyse_type_expression e1 in
                                       let (x2,t2) = analyse_type_expression e2 in
                                         if est_compatible t1 t2 then
                                            begin
                                            match op, t1, t2 with
                                            |(Plus,Int,Int) -> (Binaire(PlusInt,x1,x2),Int)
                                            |(Mult,Int,Int) -> (Binaire(MultInt,x1,x2),Int)
                                            |(Equ,Int,Int) -> (Binaire(EquInt,x1,x2),Bool)
                                            |(Fraction,Int,Int) -> (Binaire(Fraction,x1,x2),Rat)
                                            |(Mult,Rat,Rat) -> (Binaire(MultRat,x1,x2),Rat)
                                            |(Plus,Rat,Rat) -> (Binaire(PlusRat,x1,x2),Rat)
                                            |(Inf,Int,Int) -> (Binaire(Inf,x1,x2),Bool)
                                            |(Equ,Bool,Bool) -> (Binaire(EquBool,x1,x2),Bool)
                                            | _ -> raise (TypeBinaireInattendu(op,t1,t2))
                                          end
                                          else raise (TypeBinaireInattendu(op,t1,t2)) 
                                        
                                       
                                      
    


      |AstTds.Unaire(op,e) -> 
                                  let (x1,t1) = analyse_type_expression e in
                                  if (t1 = Rat) then
                                        match op with
                                        |Numerateur -> (Unaire(Numerateur,x1),Int)
                                        |Denominateur -> (Unaire(Denominateur,x1),Int)
                                  else raise (TypeInattendu(t1,Rat))
      |AstTds.Ident(info_ast) -> begin 
                                   let info = info_ast_to_info info_ast in 
                                  match info with
                                      |Tds.InfoVar(_,t,_,_) -> modifier_type_info t info_ast;
                                                             (Ident(info_ast),t) 
                                      |Tds.InfoFun(_,t,_) -> modifier_type_info t info_ast;
                                                              (Ident(info_ast),t) 
                                      |Tds.InfoConst(_,_) -> modifier_type_info Int info_ast;
                                                              (Ident(info_ast),Int)
      
                                    
                                  end
      |AstTds.AppelFonction(info_ast,es) -> begin match Tds.info_ast_to_info info_ast with 
                       | Tds.InfoFun (_,tr,ts) -> 
                        let es', ts' = List.split (List.map analyse_type_expression es ) in 
                           if est_compatible_list ts' ts 
                              then 
                              (AppelFonction (info_ast,es'),tr) 
                           else raise  (TypesParametresInattendus(ts,ts'))
                       | _ -> assert false
                          end
      

                       

                            
                  


(* analyse_type_instruction : AstSyntax.instruction -> tds -> AstTds.instruction *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre i : l'instruction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme l'instruction
en une instruction de type AstTds.instruction *)
(* Erreur si mauvaise utilisation des identifiants *)

let rec analyse_type_instruction tr instr = 
  match instr with                         
  

                                                                              
  |AstTds.Conditionnelle(e,b1,b2) -> let x,t = analyse_type_expression e in
                                        if ( t=Bool) then
                                           let x1 = analyse_type_bloc tr b1 in
                                           let x2 = analyse_type_bloc tr b2 in
                                           Conditionnelle(x,x1,x2)
                                        else raise (TypeInattendu(t,Bool))
   
  |AstTds.TantQue(e,b) -> let x,t= analyse_type_expression e in
                              if ( t=Bool) then
                               let x1 = analyse_type_bloc tr b in
                               TantQue(x,x1)
                              else raise (TypeInattendu(t,Bool))
  |AstTds.Retour(e) -> let x,t = analyse_type_expression e in
                   if tr = Undefined then 
                   raise (RetourDansMain)
                   else 
                      if est_compatible tr t then
                            Retour(x)
                      else
                            raise(TypeInattendu(t,tr))
  |AstTds.Empty -> Empty
  
  | AstTds.Declaration(t,info_ast,e) -> 
                                 let x1,t1 = analyse_type_expression e in
                                 if est_compatible t1 t then
                                   let _ = modifier_type_info t info_ast in
                                     Declaration(info_ast,x1)
                                 else
                                       raise(TypeInattendu(t1,t))

 |AstTds.Affichage(e) -> let x1,t1 = analyse_type_expression e in
        begin
            match t1 with
                      |Int -> AffichageInt(x1)
                      |Rat -> AffichageRat(x1)
                      |Bool -> AffichageBool(x1)
                      |_ -> assert false
            end
  |AstTds.Affectation(info_ast,e) -> match info_ast_to_info info_ast with
                                   |InfoVar (_,t,_,_) -> 
                                           let x,te = analyse_type_expression e in
                                           (* verifier compatibilité des types *)
                                           if est_compatible te t then 
                                        Affectation(info_ast,x)
                                        else  raise(TypeInattendu(te,t))

                                   | _ -> assert false
                                         
    
(* analyse_type_bloc : AstSyntax.bloc -> AstTds.bloc *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre li : liste d'instructions à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le bloc
en un bloc de type AstTds.bloc *)
(* Erreur si mauvaise utilisation des identifiants *)
and analyse_type_bloc tr li =
 let nli =  List.map (analyse_type_instruction tr) li in
   nli  




(* analyse_tds_fonction : AstSyntax.fonction -> AstTds.fonction *)
(* Paramètre tds : la table des symboles courante *)
(* Paramètre : la fonction à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme la fonction
en une fonction de type AstTds.fonction *)
(* Erreur si mauvaise utilisation des identifiants *)
let analyse_type_fonction (AstTds.Fonction(t,n,lp,li)) =

           
            let llp = List.map(fun (x,y) -> let () =  modifier_type_info x y in (x,y) ) lp in
            let tpl = List.map (function x,y -> x) llp
            in let () = modifier_type_fonction_info t tpl n
            in let v2 = analyse_type_bloc t li in
              let nlp = List.map (function x,y -> y) lp
              in Fonction(n,nlp,v2)
         




          

(* analyser : AstSyntax.ast -> AstTds.ast *)
(* Paramètre : le programme à analyser *)
(* Vérifie la bonne utilisation des identifiants et tranforme le programme
en un programme de type AstTds.ast *)
(* Erreur si mauvaise utilisation des identifiants *)

let analyser (AstTds.Programme (fonctions,prog)) =
  let nf = List.map (analyse_type_fonction) fonctions in 
  let nb = analyse_type_bloc Undefined prog in
  Programme (nf,nb)

end
